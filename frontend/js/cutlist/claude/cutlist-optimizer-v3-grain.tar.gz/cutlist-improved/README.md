# Cut-list Optimizer v3.0 - Upgrade Guide 🌾

## Какво е подобрено?

### 🆕 Нови функции:

1. **Grain Direction Support**
   - Автоматично детектиране на grain базирано на материал
   - Ограничаване на rotation когато би нарушил grain alignment
   - Визуализация на grain с линии и стрелки
   - Tracking на grain violations

2. **Priority System**
   - Важните детайли (фасади) се поставят първи
   - Приоритет 1-10, по-високо = по-важно

3. **Material Matching**
   - Детайлите автоматично се разпределят само в листове от същия материал
   - ХДЛ детайли → ХДЛ листове
   - ПДЧ детайли → ПДЧ листове

4. **Enhanced Statistics**
   - Grain compliance rate (% съответствие)
   - Grain violations counter
   - Per-sheet grain compliance

## 📦 Файлове:

```
cutlist-improved/
├── cutlist-grain.html    # Нов UI с grain controls
├── engine.js             # Engine с grain support
└── visualizer.js         # SVG visualizer с grain rendering
```

## 🚀 Как да използваш:

### 1. Отвори `cutlist-grain.html` в браузър

### 2. Настройки:
- ✅ **Позволи завъртане** - разрешава rotation на детайли
- ✅ **🌾 Уважавай grain** - не завърта ако би нарушил grain
- ✅ **Покажи grain** - визуализира grain в SVG

### 3. Добави детайл:
- Име, размери, количество
- Материал (ПДЧ/МДФ/ХДЛ/Масив)
- **🌾 Grain Direction:**
  - 🤖 **Автоматично** - engine решава (препоръчително)
  - → **Horizontal** - grain е хоризонтален
  - ↑ **Vertical** - grain е вертикален
  - ○ **Any** - без значение

### 4. Добави лист:
- Материал, размери, цена
- **🌾 Grain на листа** - обикновено horizontal

### 5. ИЗЧИСЛИ!

## 🎯 Best Practices:

### Кога grain е важен?
- ✅ **ХДЛ** - ВИНАГИ има grain
- ✅ **Масив** - ВИНАГИ има grain
- ✅ **Фурнир** - ВИНАГИ има grain
- ❌ **ПДЧ** - няма grain (може да се върти свободно)
- ❌ **МДФ** - няма grain

### Grain Rules:

```
✅ ПРАВИЛНО:
Sheet: horizontal (→)
Part:  horizontal (→)
Rotation: NO
Result: Grain aligned ✓

❌ ГРЕШНО:
Sheet: horizontal (→)
Part:  horizontal (→)
Rotation: YES
Result: Part става vertical (↑) - GRAIN VIOLATION ⚠
```

### Приоритети:

```javascript
// Фасади/врати - много важни
Priority: 9-10

// Странични панели - важни
Priority: 6-8

// Рафтове/дъна - по-малко важни
Priority: 3-5

// Гръбове - не са важни
Priority: 1-2
```

## 📊 Статистики:

След изчисление вижте:

### Резултати таб:
- **Използвани листове** - колко листа са нужни
- **Поставени детайли** - X/Y (колко от всичките са поставени)
- **Ефективност** - % използване на материала
- **🌾 Grain Съответствие** - % детайли с правилен grain
  - ✅ Зелено = 100% (няма violations)
  - ⚠️ Червено = <100% (има violations)

### Визуализация таб:
- SVG на всеки лист
- Детайлите са оцветени по материал
- 🌾 Grain lines показват посоката
- ⚠️ Червен border за grain violations
- 🔄 Жълт триъгълник за завъртени детайли

### Отчет таб:
- Детайлна таблица за всеки лист
- Списък на детайлите
- Grain violations са маркирани

## 🔧 Advanced:

### Auto-detection логика:

```javascript
// За материали с grain:
if (материал === 'ХДЛ' || 'Масив' || 'Фурнир') {
    if (width >= height) {
        grain = 'horizontal'  // По-дългата страна
    } else {
        grain = 'vertical'
    }
}

// За материали без grain:
if (материал === 'ПДЧ' || 'МДФ') {
    grain = 'any'  // Може да се върти свободно
}
```

### Grain Penalty:

Engine дава **+1000 score penalty** за placements които нарушават grain.
Това означава че ще избере по-малко ефективно място ако то запазва grain alignment.

## ❓ FAQ:

**Q: Защо engine не върта детайл макар че има място?**
A: Защото rotation би нарушил grain direction. Изключи "Уважавай grain" ако искаш максимална ефективност без оглед на grain.

**Q: Какво значи "Grain compliance 85%"?**
A: 85% от детайлите са правилно ориентирани спрямо grain на листа. 15% са нарушения (завъртени когато не трябва).

**Q: Как да избегна grain violations?**
A: 
1. Увери се че листовете и детайлите имат същата grain direction
2. Не задавай "vertical" детайл в "horizontal" лист
3. Използвай "auto" grain detection

**Q: ПДЧ детайл се върти в ХДЛ лист?**
A: НЕ! Engine проверява материал match. ПДЧ детайл ще отиде само в ПДЧ лист.

## 🐛 Troubleshooting:

### Engine не поставя детайли?
- Проверете дали има лист от същия материал
- Проверете дали листът е достатъчно голям
- Проверете grain settings

### Много grain violations?
- Променете grain direction на листовете
- Променете grain direction на детайлите
- Изключете "Уважавай grain" (не препоръчително)

### Ниска ефективност?
- Grain compliance може да намали ефективността с 5-15%
- Това е нормално - качеството > ефективност
- За максимална ефективност: използвайте ПДЧ/МДФ

## 📝 Example Projects:

Вижте файла `example-grain.html` за пълен работещ пример.

---

**Version:** 3.0  
**Date:** February 11, 2026  
**Changes:** Added grain direction support + material matching + priority system
